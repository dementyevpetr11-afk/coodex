# Easy OGE Backend (FastAPI)

Backend для PWA Easy OGE.

## Что уже есть
- регистрация / вход / JWT
- роли: ученик / родитель / админ
- задания: случайное по номеру, получение по ID, проверка ответа
- прогресс: общий, по темам, за 7 дней
- персональный план
- подписки
- родительская привязка и dashboard
- AI-наставник через AITunnel

## AI-модели
- **Основная модель:** `gpt-4.1-mini`
- **Поиск по базе:** `qwen3-embedding-4b`

## Как запустить на Windows
1. Распакуй архив
2. Открой папку проекта
3. В адресной строке напиши `cmd`
4. Создай окружение:
   ```bat
   py -m venv .venv
   .venv\Scriptsctivate
   ```
5. Установи зависимости:
   ```bat
   py -m pip install -r requirements.txt
   ```
6. Скопируй `.env.example` в `.env`:
   ```bat
   copy .env.example .env
   ```
7. Открой `.env` и вставь свой ключ AITunnel в строку:
   ```env
   AITUNNEL_API_KEY=твой_ключ
   ```
8. Запусти сервер:
   ```bat
   py -m uvicorn app.main:app --reload --port 8001
   ```
9. Открой docs:
   `http://127.0.0.1:8001/docs`

## Демо-аккаунты
- ученик: `student@easyoge.demo` / `1234`
- родитель: `parent@easyoge.demo` / `1234`
- админ: `admin@easyoge.demo` / `admin123`
- код родителя: `PARENT-DEMO`

## Важно
- ключ AITunnel вставляй только локально у себя в `.env`
- frontend должен обращаться к backend на `http://127.0.0.1:8001`
