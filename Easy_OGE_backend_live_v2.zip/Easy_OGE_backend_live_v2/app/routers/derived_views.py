
from fastapi import APIRouter

from app.schemas.algorithm_template import TestMapItemResponse, PriorityMapItemResponse
from app.services.algorithm_template_service import list_test_map_view, list_priority_map_view

router = APIRouter(prefix='/views', tags=['derived-views'])


@router.get('/test-map', response_model=list[TestMapItemResponse])
def test_map_view():
    return list_test_map_view()


@router.get('/priority-map', response_model=list[PriorityMapItemResponse])
def priority_map_view():
    return list_priority_map_view()
