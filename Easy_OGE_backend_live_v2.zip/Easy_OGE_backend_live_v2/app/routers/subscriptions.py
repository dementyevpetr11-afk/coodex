from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import User, UserRole
from app.routers.deps import get_current_user, require_role
from app.schemas.subscription import SubscriptionResponse, ManualActivationRequest
from app.services.subscription_service import activate_subscription

router = APIRouter(prefix='/subscriptions', tags=['subscriptions'])


@router.get('/me', response_model=SubscriptionResponse)
def my_subscription(current_user=Depends(get_current_user)):
    if not current_user.subscription:
        raise HTTPException(status_code=404, detail='Подписка не найдена')
    return current_user.subscription


@router.post('/manual-activate', response_model=SubscriptionResponse)
def manual_activate(payload: ManualActivationRequest, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    user = db.get(User, payload.user_id)
    if not user:
        raise HTTPException(status_code=404, detail='Пользователь не найден')
    return activate_subscription(db, user, payload.plan_type, current_user.email)
