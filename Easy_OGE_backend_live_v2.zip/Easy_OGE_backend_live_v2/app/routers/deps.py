from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.db import get_db
from app.models import User, UserRole, StudentProfile, ParentProfile
from app.utils.security import decode_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl='/auth/login')


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail='Не удалось проверить токен',
        headers={'WWW-Authenticate': 'Bearer'},
    )
    try:
        payload = decode_token(token)
        user_id = int(payload.get('sub'))
    except (JWTError, TypeError, ValueError):
        raise credentials_exception
    user = db.scalar(
        select(User)
        .options(
            joinedload(User.student_profile).joinedload(StudentProfile.attempts),
            joinedload(User.student_profile).joinedload(StudentProfile.ai_usage),
            joinedload(User.subscription),
            joinedload(User.parent_profile).joinedload(ParentProfile.student_links),
        )
        .where(User.id == user_id)
    )
    if not user:
        raise credentials_exception
    return user


def require_role(*roles: UserRole):
    def checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in roles:
            raise HTTPException(status_code=403, detail='Недостаточно прав')
        return current_user
    return checker
