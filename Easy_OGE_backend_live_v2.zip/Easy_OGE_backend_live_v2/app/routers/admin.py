import csv
from io import StringIO, BytesIO

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session
from openpyxl import load_workbook

from app.db import get_db
from app.models import Task, User, UserRole
from app.routers.deps import require_role
from app.schemas.task import TaskResponse, TaskCreate
from app.schemas.user import UserResponse

router = APIRouter(prefix='/admin', tags=['admin'])


@router.get('/users', response_model=list[UserResponse])
def admin_users(db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    return db.scalars(select(User).order_by(User.created_at.desc())).all()


@router.put('/tasks/{task_id}', response_model=TaskResponse)
def update_task(task_id: int, payload: TaskCreate, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(status_code=404, detail='Задание не найдено')
    for key, value in payload.model_dump().items():
        setattr(task, key, value)
    db.commit()
    db.refresh(task)
    return task


@router.delete('/tasks/{task_id}')
def delete_task(task_id: int, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(status_code=404, detail='Задание не найдено')
    db.delete(task)
    db.commit()
    return {'message': 'Задание удалено'}


@router.post('/tasks/import')
def import_tasks(file: UploadFile = File(...), db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    filename = file.filename.lower()
    rows = []
    content = file.file.read()
    if filename.endswith('.csv'):
        text = content.decode('utf-8')
        rows = list(csv.DictReader(StringIO(text)))
    elif filename.endswith('.xlsx'):
        workbook = load_workbook(BytesIO(content))
        sheet = workbook.active
        headers = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row=1))]
        for row in sheet.iter_rows(min_row=2, values_only=True):
            rows.append(dict(zip(headers, row)))
    else:
        raise HTTPException(status_code=400, detail='Поддерживаются только CSV и XLSX')

    created = 0
    for row in rows:
        task = Task(
            task_number=int(row['task_number']),
            topic=str(row['topic']),
            question_text=str(row['question_text']),
            algorithm_text=str(row['algorithm_text']),
            correct_answer=str(row['correct_answer']),
            is_open_answer=str(row.get('is_open_answer', 'false')).lower() in {'true', '1', 'yes', 'да'},
            difficulty=str(row['difficulty']) if row.get('difficulty') is not None else None,
        )
        db.add(task)
        created += 1
    db.commit()
    return {'message': 'Импорт завершён', 'created': created}
