
from fastapi import APIRouter, HTTPException

from app.schemas.algorithm_template import AlgorithmBundleResponse
from app.services.algorithm_template_service import get_algorithm_bundle

router = APIRouter(prefix='/algorithm-bundles', tags=['algorithm-bundles'])


@router.get('/{task_number}', response_model=AlgorithmBundleResponse)
def algorithm_bundle_by_task(task_number: int):
    item = get_algorithm_bundle(task_number)
    if not item:
        raise HTTPException(status_code=404, detail='Алгоритмический bundle для этого номера не найден')
    return item
