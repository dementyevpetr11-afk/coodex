from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import UserRole
from app.routers.deps import require_role
from app.schemas.progress import ProgressSummary, TopicProgressItem, DailyProgressItem
from app.services.progress_service import build_progress_summary, build_topic_progress, build_last_7_days

router = APIRouter(prefix='/progress', tags=['progress'])


@router.get('/me', response_model=ProgressSummary)
def my_progress(db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    return build_progress_summary(db, current_user.student_profile)


@router.get('/topics', response_model=list[TopicProgressItem])
def topic_progress(db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    return build_topic_progress(db, current_user.student_profile)


@router.get('/last-7-days', response_model=list[DailyProgressItem])
def last_7_days(db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    return build_last_7_days(db, current_user.student_profile)
