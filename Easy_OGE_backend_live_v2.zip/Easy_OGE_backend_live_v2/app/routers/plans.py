from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import StudyPlan, UserRole
from app.routers.deps import require_role
from app.schemas.plan import PlanCreateRequest, PlanResponse
from app.services.plan_service import create_plan

router = APIRouter(prefix='/plans', tags=['plans'])


@router.post('/create', response_model=PlanResponse)
def create_study_plan(payload: PlanCreateRequest, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    return create_plan(db, current_user.student_profile, payload)


@router.get('/current', response_model=PlanResponse)
def current_plan(db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    plan = db.scalar(select(StudyPlan).where(StudyPlan.student_id == current_user.student_profile.id, StudyPlan.is_active == True))
    if not plan:
        raise HTTPException(status_code=404, detail='Активный план не найден')
    return plan
