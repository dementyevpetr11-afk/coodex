
from fastapi import APIRouter, HTTPException

from app.schemas.algorithm_template import AuthoringAlgorithmTemplateResponse
from app.services.algorithm_template_service import list_algorithm_templates, get_algorithm_template

router = APIRouter(prefix='/algorithm-templates', tags=['algorithm-templates'])


@router.get('/', response_model=list[AuthoringAlgorithmTemplateResponse])
def algorithm_templates_list():
    return list_algorithm_templates()


@router.get('/{task_number}', response_model=AuthoringAlgorithmTemplateResponse)
def algorithm_template_by_task(task_number: int):
    template = get_algorithm_template(task_number)
    if not template:
        raise HTTPException(status_code=404, detail='Алгоритм для этого номера не найден')
    return template
