from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import ParentStudentLink, StudentProfile, UserRole
from app.routers.deps import require_role
from app.schemas.parent import LinkStudentRequest, ParentDashboardResponse
from app.services.parent_service import link_student_by_code, build_parent_dashboard

router = APIRouter(prefix='/parent', tags=['parent'])


@router.post('/link-student')
def link_student(payload: LinkStudentRequest, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.parent))):
    link = link_student_by_code(db, current_user.parent_profile, payload.access_code)
    if not link:
        raise HTTPException(status_code=404, detail='Не удалось привязать ученика')
    return {'message': 'Ученик привязан', 'student_id': link.student_id}


@router.get('/dashboard/{student_id}', response_model=ParentDashboardResponse)
def parent_dashboard(student_id: int, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.parent, UserRole.admin))):
    student = db.get(StudentProfile, student_id)
    if not student:
        raise HTTPException(status_code=404, detail='Ученик не найден')
    if current_user.role == UserRole.parent:
        link = db.scalar(select(ParentStudentLink).where(ParentStudentLink.parent_id == current_user.parent_profile.id, ParentStudentLink.student_id == student_id))
        if not link:
            raise HTTPException(status_code=403, detail='Нет доступа к этому ученику')
    return build_parent_dashboard(db, student)
