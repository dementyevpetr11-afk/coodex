from fastapi import APIRouter, Depends

from app.models import UserRole
from app.routers.deps import require_role
from app.schemas.ai import AIChatRequest, AIChatResponse
from app.services.ai_service import answer_student_message, get_remaining_limit
from app.db import SessionLocal

router = APIRouter(prefix='/ai', tags=['ai'])


@router.get('/limits')
def ai_limits(current_user=Depends(require_role(UserRole.student))):
    return {'remaining_today': get_remaining_limit(current_user.student_profile)}


@router.post('/chat', response_model=AIChatResponse)
def ai_chat(payload: AIChatRequest, current_user=Depends(require_role(UserRole.student))):
    with SessionLocal() as db:
        student = db.get(type(current_user.student_profile), current_user.student_profile.id)
        answer, remaining, metadata = answer_student_message(db, student, payload.message)
        metadata = metadata or {}
        return AIChatResponse(
            answer=answer,
            remaining_today=remaining,
            matched_topic=metadata.get('matched_topic'),
            matched_task_number=metadata.get('matched_task_number'),
            matched_task_code=metadata.get('matched_task_code'),
        )
