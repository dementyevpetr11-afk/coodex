from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import User
from app.schemas.auth import RegisterRequest, TokenResponse
from app.schemas.user import UserResponse
from app.services.auth_service import register_user, authenticate_user, create_token_for_user
from app.routers.deps import get_current_user

router = APIRouter(prefix='/auth', tags=['auth'])


@router.post('/register', response_model=UserResponse)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    existing = db.scalar(select(User).where(User.email == payload.email))
    if existing:
        raise HTTPException(status_code=400, detail='Пользователь с таким email уже существует')
    return register_user(db, payload)


@router.post('/login', response_model=TokenResponse)
async def login(request: Request, db: Session = Depends(get_db)):
    content_type = request.headers.get('content-type', '')

    email = None
    password = None

    if 'application/x-www-form-urlencoded' in content_type or 'multipart/form-data' in content_type:
        form = await request.form()
        email = form.get('username') or form.get('email')
        password = form.get('password')
    else:
        data = await request.json()
        email = data.get('email') or data.get('username')
        password = data.get('password')

    if not email or not password:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail='Нужны email/username и password',
        )

    user = authenticate_user(db, email, password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Неверный email или пароль')
    token = create_token_for_user(user)
    return TokenResponse(access_token=token)


@router.get('/me', response_model=UserResponse)
def me(current_user=Depends(get_current_user)):
    return current_user
