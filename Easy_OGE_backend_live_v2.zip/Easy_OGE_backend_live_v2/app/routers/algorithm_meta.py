
from fastapi import APIRouter, HTTPException

from app.schemas.algorithm_template import MachineMetaResponse
from app.services.algorithm_template_service import list_algorithm_meta, get_algorithm_meta

router = APIRouter(prefix='/algorithm-meta', tags=['algorithm-meta'])


@router.get('/', response_model=list[MachineMetaResponse])
def algorithm_meta_list():
    return list_algorithm_meta()


@router.get('/{task_number}', response_model=MachineMetaResponse)
def algorithm_meta_by_task(task_number: int):
    item = get_algorithm_meta(task_number)
    if not item:
        raise HTTPException(status_code=404, detail='Machine meta для этого номера не найден')
    return item
