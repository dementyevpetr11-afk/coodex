from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import Task, UserRole
from app.routers.deps import get_current_user, require_role
from app.schemas.task import TaskResponse, AnswerCheckRequest, AnswerCheckResponse, TaskCreate
from app.services.task_service import get_random_task_by_number, check_answer

router = APIRouter(prefix='/tasks', tags=['tasks'])


@router.get('/random', response_model=TaskResponse)
def random_task(number: int, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    task = get_random_task_by_number(db, number)
    if not task:
        raise HTTPException(status_code=404, detail='Задания с таким номером не найдено')
    return task


@router.get('/{task_id}', response_model=TaskResponse)
def get_task(task_id: int, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(status_code=404, detail='Задание не найдено')
    return task


@router.post('/{task_id}/check-answer', response_model=AnswerCheckResponse)
def check_task_answer(task_id: int, payload: AnswerCheckRequest, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(status_code=404, detail='Задание не найдено')
    is_correct = check_answer(db, current_user.student_profile, task, payload.answer)
    if task.is_open_answer:
        return AnswerCheckResponse(
            is_correct=False,
            expected=None,
            is_open_answer=True,
            message='Это задание с развёрнутым ответом. Отправь его на проверку преподавателю или менеджеру.',
        )
    return AnswerCheckResponse(
        is_correct=is_correct,
        expected=task.correct_answer if not is_correct else None,
        is_open_answer=False,
        message='Верно!' if is_correct else 'Неверно. Попробуй ещё раз.',
    )


@router.get('/', response_model=list[TaskResponse])
def list_tasks(db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    return db.scalars(select(Task).order_by(Task.task_number, Task.id)).all()


@router.post('/', response_model=TaskResponse)
def create_task(payload: TaskCreate, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    task = Task(**payload.model_dump())
    db.add(task)
    db.commit()
    db.refresh(task)
    return task
