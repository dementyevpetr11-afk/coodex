
from fastapi import APIRouter, HTTPException

from app.schemas.algorithm_template import MobileShortCardResponse
from app.services.algorithm_template_service import list_mobile_short_cards, get_mobile_short_card

router = APIRouter(prefix='/mobile-short-cards', tags=['mobile-short-cards'])


@router.get('/', response_model=list[MobileShortCardResponse])
def mobile_short_cards_list():
    return list_mobile_short_cards()


@router.get('/{task_number}', response_model=MobileShortCardResponse)
def mobile_short_card_by_task(task_number: int):
    item = get_mobile_short_card(task_number)
    if not item:
        raise HTTPException(status_code=404, detail='Короткая карточка для этого номера не найдена')
    return item
