
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.db import get_db
from app.models import OpenAnswerSubmission, Task, UserRole
from app.routers.deps import require_role
from app.schemas.open_answer import OpenAnswerSubmitRequest, OpenAnswerSubmissionResponse, OpenAnswerReviewRequest
from app.services.open_answer_service import submit_open_answer, rerun_ai_draft, manager_review_submission

router = APIRouter(prefix='/open-answers', tags=['open-answers'])


@router.post('/submit', response_model=OpenAnswerSubmissionResponse)
def submit_answer(payload: OpenAnswerSubmitRequest, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    task = db.get(Task, payload.task_id)
    if not task:
        raise HTTPException(status_code=404, detail='Задание не найдено')
    if not task.is_open_answer:
        raise HTTPException(status_code=400, detail='Это не задание с развёрнутым ответом')
    text = (payload.answer_text or '').strip()
    if not text:
        raise HTTPException(status_code=422, detail='Ответ не может быть пустым')
    submission = submit_open_answer(db, current_user.student_profile, task, text)
    return submission


@router.get('/my', response_model=list[OpenAnswerSubmissionResponse])
def my_submissions(db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.student))):
    return db.scalars(
        select(OpenAnswerSubmission)
        .where(OpenAnswerSubmission.student_id == current_user.student_profile.id)
        .order_by(OpenAnswerSubmission.created_at.desc())
    ).all()


@router.get('/queue', response_model=list[OpenAnswerSubmissionResponse])
def review_queue(db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    return db.scalars(
        select(OpenAnswerSubmission)
        .options(joinedload(OpenAnswerSubmission.task))
        .order_by(OpenAnswerSubmission.created_at.desc())
    ).all()


@router.post('/{submission_id}/ai-draft', response_model=OpenAnswerSubmissionResponse)
def regenerate_ai_draft(submission_id: int, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    submission = db.scalar(select(OpenAnswerSubmission).where(OpenAnswerSubmission.id == submission_id))
    if not submission:
        raise HTTPException(status_code=404, detail='Отправка не найдена')
    return rerun_ai_draft(db, submission)


@router.post('/{submission_id}/review', response_model=OpenAnswerSubmissionResponse)
def review_submission(submission_id: int, payload: OpenAnswerReviewRequest, db: Session = Depends(get_db), current_user=Depends(require_role(UserRole.admin))):
    submission = db.scalar(select(OpenAnswerSubmission).where(OpenAnswerSubmission.id == submission_id))
    if not submission:
        raise HTTPException(status_code=404, detail='Отправка не найдена')
    return manager_review_submission(db, submission, payload.manager_score, payload.manager_comment)
