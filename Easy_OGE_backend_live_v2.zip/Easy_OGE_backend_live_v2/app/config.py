from functools import lru_cache
from typing import List

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore')

    app_name: str = 'Easy OGE Backend'
    secret_key: str = 'change-me-super-secret-key'
    access_token_expire_minutes: int = 60 * 24 * 7
    database_url: str = 'sqlite:///./easy_oge.db'
    redis_url: str = 'redis://localhost:6379/0'
    cors_origins: List[str] | str = ['http://localhost:8000', 'http://127.0.0.1:8000']

    # AITunnel / LLM
    ai_enabled: bool = True
    aitunnel_base_url: str = 'https://api.aitunnel.ru/v1'
    aitunnel_api_key: str = ''
    ai_chat_model: str = 'gpt-4.1-mini'
    ai_embedding_model: str = 'qwen3-embedding-4b'
    ai_top_k: int = 3
    ai_timeout_seconds: int = 60

    @field_validator('cors_origins', mode='before')
    @classmethod
    def parse_cors_origins(cls, value):
        if isinstance(value, str):
            return [item.strip() for item in value.split(',') if item.strip()]
        return value


@lru_cache
def get_settings() -> Settings:
    return Settings()
