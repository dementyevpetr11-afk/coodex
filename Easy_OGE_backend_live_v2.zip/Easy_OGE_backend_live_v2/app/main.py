from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.db import Base, engine, SessionLocal
from app.models import *  # noqa: F401,F403
from app.routers import auth, tasks, progress, plans, subscriptions, parent, ai, admin, algorithm_templates, algorithm_meta, mobile_short_cards, algorithm_bundles, derived_views, open_answers
from app.seed import seed_demo_data

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed_demo_data(db)
    yield


app = FastAPI(title=settings.app_name, version='0.1.0', lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)


@app.get('/')
def root():
    return {
        'name': settings.app_name,
        'status': 'ok',
        'docs': '/docs',
        'message': 'Easy OGE backend запущен',
    }


app.include_router(auth.router)
app.include_router(tasks.router)
app.include_router(progress.router)
app.include_router(plans.router)
app.include_router(subscriptions.router)
app.include_router(parent.router)
app.include_router(ai.router)
app.include_router(admin.router)

app.include_router(algorithm_templates.router)

app.include_router(algorithm_meta.router)
app.include_router(mobile_short_cards.router)
app.include_router(algorithm_bundles.router)
app.include_router(derived_views.router)

app.include_router(open_answers.router)
