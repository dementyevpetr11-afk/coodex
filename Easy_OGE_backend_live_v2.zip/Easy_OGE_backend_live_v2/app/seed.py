from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import (
    User, UserRole, StudentProfile, ParentProfile, ParentStudentLink,
    Subscription, PlanType, Task
)
from app.utils.security import hash_password


DEMO_TASKS = [
    {
        'task_number': 2,
        'topic': 'экономика',
        'question_text': 'Что из перечисленного является фактором производства?',
        'algorithm_text': '1. Найди, что участвует в создании товара или услуги. 2. Исключи результат производства. 3. Выбери ресурс, который используется в процессе труда.',
        'correct_answer': 'труд',
        'is_open_answer': False,
        'difficulty': 'easy',
    },
    {
        'task_number': 12,
        'topic': 'экономика',
        'question_text': 'Объясни, как работает спрос и предложение на примере яблок.',
        'algorithm_text': '1. Определи, что спрос — это желание и возможность купить. 2. Предложение — сколько товара готовы продать. 3. Сравни, что происходит при избытке или дефиците.',
        'correct_answer': 'развёрнутый ответ',
        'is_open_answer': True,
        'difficulty': 'medium',
    },
    {
        'task_number': 8,
        'topic': 'право',
        'question_text': 'Какой орган в РФ осуществляет правосудие?',
        'algorithm_text': '1. Найди орган, который решает споры по закону. 2. Исключи органы исполнительной власти. 3. Выбери судебную систему.',
        'correct_answer': 'суд',
        'is_open_answer': False,
        'difficulty': 'easy',
    },
    {
        'task_number': 16,
        'topic': 'политика',
        'question_text': 'Что отличает демократический режим?',
        'algorithm_text': '1. Вспомни признаки демократии. 2. Проверь, есть ли выборы и права граждан. 3. Исключи авторитарные признаки.',
        'correct_answer': 'свободные выборы',
        'is_open_answer': False,
        'difficulty': 'medium',
    },
]


def seed_demo_data(db: Session):
    if not db.scalar(select(User).where(User.email == 'admin@easyoge.demo')):
        admin = User(name='Easy OGE Admin', email='admin@easyoge.demo', role=UserRole.admin, password_hash=hash_password('admin123'))
        db.add(admin)
        db.flush()
        db.add(Subscription(user_id=admin.id, plan_type=PlanType.pro, activated_by_admin='system'))

    student_user = db.scalar(select(User).where(User.email == 'student@easyoge.demo'))
    if not student_user:
        student_user = User(name='Demo Student', email='student@easyoge.demo', role=UserRole.student, password_hash=hash_password('1234'))
        db.add(student_user)
        db.flush()
        student_profile = StudentProfile(user_id=student_user.id)
        db.add(student_profile)
        db.add(Subscription(user_id=student_user.id, plan_type=PlanType.basic, activated_by_admin='system'))

    parent_user = db.scalar(select(User).where(User.email == 'parent@easyoge.demo'))
    if not parent_user:
        parent_user = User(name='Demo Parent', email='parent@easyoge.demo', role=UserRole.parent, password_hash=hash_password('1234'))
        db.add(parent_user)
        db.flush()
        parent_profile = ParentProfile(user_id=parent_user.id)
        db.add(parent_profile)
        db.add(Subscription(user_id=parent_user.id, plan_type=PlanType.pro, activated_by_admin='system'))

    db.commit()

    student_profile = db.scalar(select(StudentProfile).join(User).where(User.email == 'student@easyoge.demo'))
    parent_profile = db.scalar(select(ParentProfile).join(User).where(User.email == 'parent@easyoge.demo'))
    link = db.scalar(select(ParentStudentLink).where(ParentStudentLink.access_code == 'PARENT-DEMO'))
    if student_profile and parent_profile and not link:
        db.add(ParentStudentLink(parent_id=parent_profile.id, student_id=student_profile.id, access_code='PARENT-DEMO'))

    for task_data in DEMO_TASKS:
        exists = db.scalar(select(Task).where(Task.task_number == task_data['task_number'], Task.question_text == task_data['question_text']))
        if not exists:
            db.add(Task(**task_data))

    db.commit()
