from datetime import datetime, date, time

from sqlalchemy import Date, DateTime, ForeignKey, Integer, Time
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class StudentProfile(Base):
    __tablename__ = 'student_profiles'

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), unique=True, nullable=False)
    exam_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    target_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    daily_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    notification_time: Mapped[time | None] = mapped_column(Time, nullable=True)
    last_activity_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    user = relationship('User', back_populates='student_profile')
    attempts = relationship('Attempt', back_populates='student', cascade='all, delete-orphan')
    study_plans = relationship('StudyPlan', back_populates='student', cascade='all, delete-orphan')
    ai_usage = relationship('AIUsage', back_populates='student', cascade='all, delete-orphan')
    ai_messages = relationship('AIMessage', back_populates='student', cascade='all, delete-orphan')
    mock_tests = relationship('MockTest', back_populates='student', cascade='all, delete-orphan')
    open_answer_submissions = relationship('OpenAnswerSubmission', back_populates='student', cascade='all, delete-orphan')
