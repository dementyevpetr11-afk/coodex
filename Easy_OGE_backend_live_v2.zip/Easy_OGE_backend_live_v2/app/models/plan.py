from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class StudyPlan(Base):
    __tablename__ = 'study_plans'

    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey('student_profiles.id'), nullable=False, index=True)
    exam_date: Mapped[date] = mapped_column(Date, nullable=False)
    target_score: Mapped[int] = mapped_column(Integer, nullable=False)
    daily_minutes: Mapped[int] = mapped_column(Integer, nullable=False)
    tasks_per_day: Mapped[int] = mapped_column(Integer, nullable=False)
    current_day: Mapped[int] = mapped_column(Integer, default=1)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    student = relationship('StudentProfile', back_populates='study_plans')
    items = relationship('DailyPlanItem', back_populates='plan', cascade='all, delete-orphan')


class DailyPlanItem(Base):
    __tablename__ = 'daily_plan_items'

    id: Mapped[int] = mapped_column(primary_key=True)
    plan_id: Mapped[int] = mapped_column(ForeignKey('study_plans.id'), nullable=False, index=True)
    task_id: Mapped[int] = mapped_column(ForeignKey('tasks.id'), nullable=False)
    scheduled_date: Mapped[date] = mapped_column(Date, nullable=False)
    is_completed: Mapped[bool] = mapped_column(Boolean, default=False)

    plan = relationship('StudyPlan', back_populates='items')
    task = relationship('Task')
