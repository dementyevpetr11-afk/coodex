from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class Attempt(Base):
    __tablename__ = 'attempts'

    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey('student_profiles.id'), nullable=False, index=True)
    task_id: Mapped[int] = mapped_column(ForeignKey('tasks.id'), nullable=False, index=True)
    user_answer: Mapped[str] = mapped_column(Text, nullable=False)
    is_correct: Mapped[bool] = mapped_column(Boolean, nullable=False)
    checked_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    student = relationship('StudentProfile', back_populates='attempts')
    task = relationship('Task', back_populates='attempts')
