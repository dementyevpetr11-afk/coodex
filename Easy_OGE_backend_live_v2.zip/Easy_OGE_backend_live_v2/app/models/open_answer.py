
from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import DateTime, Enum, ForeignKey, Integer, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class OpenAnswerStatus(str, enum.Enum):
    pending = 'pending'
    ai_drafted = 'ai_drafted'
    reviewed = 'reviewed'


class OpenAnswerSubmission(Base):
    __tablename__ = 'open_answer_submissions'

    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey('student_profiles.id'), nullable=False, index=True)
    task_id: Mapped[int] = mapped_column(ForeignKey('tasks.id'), nullable=False, index=True)
    answer_text: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[OpenAnswerStatus] = mapped_column(Enum(OpenAnswerStatus), default=OpenAnswerStatus.pending, nullable=False, index=True)
    ai_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ai_comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    ai_payload_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    manager_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    manager_comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    student = relationship('StudentProfile', back_populates='open_answer_submissions')
    task = relationship('Task', back_populates='open_answer_submissions')
