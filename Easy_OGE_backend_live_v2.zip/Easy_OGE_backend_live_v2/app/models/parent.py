from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class ParentProfile(Base):
    __tablename__ = 'parent_profiles'

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), unique=True, nullable=False)

    user = relationship('User', back_populates='parent_profile')
    student_links = relationship('ParentStudentLink', back_populates='parent', cascade='all, delete-orphan')


class ParentStudentLink(Base):
    __tablename__ = 'parent_student_links'

    id: Mapped[int] = mapped_column(primary_key=True)
    parent_id: Mapped[int] = mapped_column(ForeignKey('parent_profiles.id'), nullable=False)
    student_id: Mapped[int] = mapped_column(ForeignKey('student_profiles.id'), nullable=False)
    access_code: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    parent = relationship('ParentProfile', back_populates='student_links')
    student = relationship('StudentProfile')
