from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, Boolean, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class MockTest(Base):
    __tablename__ = 'mock_tests'

    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey('student_profiles.id'), nullable=False, index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    percent: Mapped[int | None] = mapped_column(Integer, nullable=True)

    student = relationship('StudentProfile', back_populates='mock_tests')
    items = relationship('MockTestItem', back_populates='mock_test', cascade='all, delete-orphan')


class MockTestItem(Base):
    __tablename__ = 'mock_test_items'

    id: Mapped[int] = mapped_column(primary_key=True)
    mock_test_id: Mapped[int] = mapped_column(ForeignKey('mock_tests.id'), nullable=False, index=True)
    task_id: Mapped[int] = mapped_column(ForeignKey('tasks.id'), nullable=False)
    user_answer: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_correct: Mapped[bool | None] = mapped_column(Boolean, nullable=True)

    mock_test = relationship('MockTest', back_populates='items')
    task = relationship('Task')
