from app.models.user import User, UserRole
from app.models.student import StudentProfile
from app.models.parent import ParentProfile, ParentStudentLink
from app.models.task import Task
from app.models.attempt import Attempt
from app.models.subscription import Subscription, PlanType, SubscriptionStatus
from app.models.plan import StudyPlan, DailyPlanItem
from app.models.ai import AIUsage, AIMessage
from app.models.mock_test import MockTest, MockTestItem

from app.models.open_answer import OpenAnswerSubmission, OpenAnswerStatus
