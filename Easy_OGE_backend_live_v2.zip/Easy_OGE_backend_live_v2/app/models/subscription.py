import enum
from datetime import datetime

from sqlalchemy import DateTime, Enum, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class PlanType(str, enum.Enum):
    free = 'free'
    basic = 'basic'
    pro = 'pro'


class SubscriptionStatus(str, enum.Enum):
    active = 'active'
    inactive = 'inactive'


class Subscription(Base):
    __tablename__ = 'subscriptions'

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'), unique=True, nullable=False)
    plan_type: Mapped[PlanType] = mapped_column(Enum(PlanType), default=PlanType.free, nullable=False)
    status: Mapped[SubscriptionStatus] = mapped_column(Enum(SubscriptionStatus), default=SubscriptionStatus.active, nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    activated_by_admin: Mapped[str | None] = mapped_column(String(255), nullable=True)

    user = relationship('User', back_populates='subscription')
