from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import ParentStudentLink, StudentProfile, ParentProfile
from app.services.progress_service import build_progress_summary, build_topic_progress


def link_student_by_code(db: Session, parent: ParentProfile, access_code: str) -> ParentStudentLink | None:
    link = db.scalar(select(ParentStudentLink).where(ParentStudentLink.access_code == access_code))
    if link:
        return link
    demo_student = db.scalar(select(StudentProfile).join(StudentProfile.user).where(StudentProfile.user.has(email='student@easyoge.demo')))
    if not demo_student:
        return None
    link = ParentStudentLink(parent_id=parent.id, student_id=demo_student.id, access_code=access_code)
    db.add(link)
    db.commit()
    db.refresh(link)
    return link


def build_parent_dashboard(db: Session, student: StudentProfile) -> dict:
    summary = build_progress_summary(db, student)
    topics = build_topic_progress(db, student)
    return {
        'student_name': student.user.name,
        'last_activity_at': student.last_activity_at.isoformat() if student.last_activity_at else None,
        'topics': topics,
        **summary,
    }
