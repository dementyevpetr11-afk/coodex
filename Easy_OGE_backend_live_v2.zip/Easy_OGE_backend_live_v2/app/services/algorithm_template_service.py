
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

DATA_DIR = Path(__file__).resolve().parents[1] / 'data'
AUTHORING_PATH = DATA_DIR / 'easy_oge_authoring_layer_v2.json'
MACHINE_META_PATH = DATA_DIR / 'easy_oge_machine_meta_v2.json'
MOBILE_SHORT_CARDS_PATH = DATA_DIR / 'easy_oge_mobile_short_cards_v2_1.json'
TEST_MAP_VIEW_PATH = DATA_DIR / 'easy_oge_test_map_view_v2.json'
PRIORITY_MAP_VIEW_PATH = DATA_DIR / 'easy_oge_priority_map_v2.json'


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


@lru_cache
def load_authoring_layer() -> list[dict[str, Any]]:
    return _load_json(AUTHORING_PATH)


@lru_cache
def load_machine_meta() -> list[dict[str, Any]]:
    return _load_json(MACHINE_META_PATH)


@lru_cache
def load_mobile_short_cards() -> list[dict[str, Any]]:
    return _load_json(MOBILE_SHORT_CARDS_PATH)


@lru_cache
def load_test_map_view() -> list[dict[str, Any]]:
    return _load_json(TEST_MAP_VIEW_PATH)


@lru_cache
def load_priority_map_view() -> list[dict[str, Any]]:
    return _load_json(PRIORITY_MAP_VIEW_PATH)


@lru_cache
def get_authoring_map() -> dict[int, dict[str, Any]]:
    return {int(item['task_number']): item for item in load_authoring_layer()}


@lru_cache
def get_machine_meta_map() -> dict[int, dict[str, Any]]:
    return {int(item['task_number']): item for item in load_machine_meta()}


@lru_cache
def get_mobile_short_card_map() -> dict[int, dict[str, Any]]:
    return {int(item['task_number']): item for item in load_mobile_short_cards()}


def list_algorithm_templates() -> list[dict[str, Any]]:
    return load_authoring_layer()


def get_algorithm_template(task_number: int) -> dict[str, Any] | None:
    return get_authoring_map().get(int(task_number))


def list_algorithm_meta() -> list[dict[str, Any]]:
    return load_machine_meta()


def get_algorithm_meta(task_number: int) -> dict[str, Any] | None:
    return get_machine_meta_map().get(int(task_number))


def list_mobile_short_cards() -> list[dict[str, Any]]:
    return load_mobile_short_cards()


def get_mobile_short_card(task_number: int) -> dict[str, Any] | None:
    return get_mobile_short_card_map().get(int(task_number))


def list_test_map_view() -> list[dict[str, Any]]:
    return load_test_map_view()


def list_priority_map_view() -> list[dict[str, Any]]:
    return load_priority_map_view()


def get_algorithm_bundle(task_number: int) -> dict[str, Any] | None:
    authoring = get_algorithm_template(task_number)
    if not authoring:
        return None
    return {
        'task_number': int(task_number),
        'task_code': authoring['task_code'],
        'authoring': authoring,
        'machine_meta': get_algorithm_meta(task_number),
        'mobile_short_card': get_mobile_short_card(task_number),
    }
