from datetime import datetime, timedelta
from collections import defaultdict

from sqlalchemy import select, func
from sqlalchemy.orm import Session

from app.models import Attempt, Task, StudentProfile
from app.utils.helpers import calculate_streak


def build_progress_summary(db: Session, student: StudentProfile) -> dict:
    attempts = db.scalars(select(Attempt).where(Attempt.student_id == student.id)).all()
    total_solved = len(attempts)
    total_correct = sum(1 for item in attempts if item.is_correct)
    total_wrong = total_solved - total_correct
    accuracy = round((total_correct / total_solved) * 100, 2) if total_solved else 0.0
    streak = calculate_streak([item.checked_at.date() for item in attempts])
    return {
        'total_solved': total_solved,
        'total_correct': total_correct,
        'total_wrong': total_wrong,
        'accuracy_percent': accuracy,
        'streak_days': streak,
    }


def build_topic_progress(db: Session, student: StudentProfile) -> list[dict]:
    attempts = db.scalars(
        select(Attempt).where(Attempt.student_id == student.id)
    ).all()
    data = defaultdict(lambda: {'solved_count': 0, 'correct_count': 0})
    for attempt in attempts:
        topic = attempt.task.topic
        data[topic]['solved_count'] += 1
        if attempt.is_correct:
            data[topic]['correct_count'] += 1
    result = []
    for topic, stats in data.items():
        solved = stats['solved_count']
        correct = stats['correct_count']
        result.append({
            'topic': topic,
            'solved_count': solved,
            'correct_count': correct,
            'accuracy_percent': round((correct / solved) * 100, 2) if solved else 0.0,
        })
    return sorted(result, key=lambda x: x['topic'])


def build_last_7_days(db: Session, student: StudentProfile) -> list[dict]:
    since = datetime.utcnow() - timedelta(days=6)
    attempts = db.scalars(
        select(Attempt).where(Attempt.student_id == student.id, Attempt.checked_at >= since)
    ).all()
    grouped = defaultdict(lambda: {'solved': 0, 'correct': 0})
    for attempt in attempts:
        key = attempt.checked_at.date().isoformat()
        grouped[key]['solved'] += 1
        if attempt.is_correct:
            grouped[key]['correct'] += 1
    today = datetime.utcnow().date()
    result = []
    for i in range(6, -1, -1):
        day = (today - timedelta(days=i)).isoformat()
        result.append({'date': day, 'solved': grouped[day]['solved'], 'correct': grouped[day]['correct']})
    return result
