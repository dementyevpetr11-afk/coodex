from datetime import datetime, timedelta
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Subscription, PlanType, SubscriptionStatus, User


def activate_subscription(db: Session, user: User, plan_type: PlanType, activated_by_admin: str) -> Subscription:
    subscription = user.subscription
    if not subscription:
        subscription = Subscription(user_id=user.id)
        db.add(subscription)
    subscription.plan_type = plan_type
    subscription.status = SubscriptionStatus.active
    subscription.started_at = datetime.utcnow()
    if plan_type == PlanType.basic:
        subscription.expires_at = datetime.utcnow() + timedelta(days=30)
    elif plan_type == PlanType.pro:
        subscription.expires_at = datetime.utcnow() + timedelta(days=270)
    else:
        subscription.expires_at = None
    subscription.activated_by_admin = activated_by_admin
    db.commit()
    db.refresh(subscription)
    return subscription
