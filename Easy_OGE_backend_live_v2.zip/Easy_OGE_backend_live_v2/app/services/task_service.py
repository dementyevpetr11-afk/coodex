import random
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Task, Attempt, StudentProfile
from app.utils.helpers import normalize_answer


def get_random_task_by_number(db: Session, number: int) -> Task | None:
    tasks = db.scalars(select(Task).where(Task.task_number == number)).all()
    if not tasks:
        return None
    return random.choice(tasks)


def check_answer(db: Session, student: StudentProfile, task: Task, answer: str) -> bool:
    if task.is_open_answer:
        is_correct = False
    else:
        is_correct = normalize_answer(answer) == normalize_answer(task.correct_answer)

    attempt = Attempt(student_id=student.id, task_id=task.id, user_answer=answer, is_correct=is_correct)
    db.add(attempt)
    student.last_activity_at = attempt.checked_at
    db.commit()
    return is_correct
