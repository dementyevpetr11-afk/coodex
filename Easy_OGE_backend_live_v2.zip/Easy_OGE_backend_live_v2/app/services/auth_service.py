from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import User, StudentProfile, ParentProfile, Subscription, PlanType
from app.schemas.auth import RegisterRequest
from app.utils.security import hash_password, verify_password, create_access_token

settings = get_settings()


def register_user(db: Session, payload: RegisterRequest) -> User:
    user = User(
        name=payload.name,
        email=payload.email,
        phone=payload.phone,
        role=payload.role,
        password_hash=hash_password(payload.password),
    )
    db.add(user)
    db.flush()

    if payload.role.value == 'student':
        db.add(StudentProfile(user_id=user.id))
    elif payload.role.value == 'parent':
        db.add(ParentProfile(user_id=user.id))

    db.add(Subscription(user_id=user.id, plan_type=PlanType.free))
    db.commit()
    db.refresh(user)
    return user


def authenticate_user(db: Session, email: str, password: str) -> User | None:
    user = db.scalar(select(User).where(User.email == email))
    if not user or not verify_password(password, user.password_hash):
        return None
    return user


def create_token_for_user(user: User) -> str:
    return create_access_token(user.id, timedelta(minutes=settings.access_token_expire_minutes))
