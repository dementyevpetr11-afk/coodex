from datetime import date
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import StudyPlan, DailyPlanItem, Task, StudentProfile
from app.schemas.plan import PlanCreateRequest


def calculate_tasks_per_day(target_score: int, exam_date: date, daily_minutes: int) -> int:
    days_until_exam = max(1, (exam_date - date.today()).days)
    raw = max(1, round((target_score * 3) / days_until_exam))
    if daily_minutes <= 15:
        return min(raw, 2)
    if daily_minutes <= 30:
        return min(raw, 4)
    return min(raw, 6)


def create_plan(db: Session, student: StudentProfile, payload: PlanCreateRequest) -> StudyPlan:
    existing = db.scalars(select(StudyPlan).where(StudyPlan.student_id == student.id, StudyPlan.is_active == True)).all()
    for plan in existing:
        plan.is_active = False
    tasks_per_day = calculate_tasks_per_day(payload.target_score, payload.exam_date, payload.daily_minutes)
    plan = StudyPlan(
        student_id=student.id,
        exam_date=payload.exam_date,
        target_score=payload.target_score,
        daily_minutes=payload.daily_minutes,
        tasks_per_day=tasks_per_day,
    )
    db.add(plan)
    db.flush()

    tasks = db.scalars(select(Task).limit(tasks_per_day)).all()
    for task in tasks:
        db.add(DailyPlanItem(plan_id=plan.id, task_id=task.id, scheduled_date=date.today()))

    student.exam_date = payload.exam_date
    student.target_score = payload.target_score
    student.daily_minutes = payload.daily_minutes
    student.notification_time = payload.notification_time

    db.commit()
    db.refresh(plan)
    return plan
