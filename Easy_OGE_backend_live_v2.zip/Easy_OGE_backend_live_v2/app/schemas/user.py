from datetime import datetime
from pydantic import BaseModel, EmailStr

from app.models.user import UserRole
from app.models.subscription import PlanType, SubscriptionStatus


class SubscriptionInfo(BaseModel):
    plan_type: PlanType
    status: SubscriptionStatus


class UserResponse(BaseModel):
    id: int
    role: UserRole
    name: str
    email: EmailStr
    phone: str | None = None
    created_at: datetime
    subscription: SubscriptionInfo | None = None

    model_config = {'from_attributes': True}
