from pydantic import BaseModel


class AIChatRequest(BaseModel):
    message: str


class AIChatResponse(BaseModel):
    answer: str
    remaining_today: int
    matched_topic: str | None = None
    matched_task_number: int | None = None
    matched_task_code: str | None = None
