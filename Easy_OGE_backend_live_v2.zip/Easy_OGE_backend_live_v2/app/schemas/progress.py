from pydantic import BaseModel


class ProgressSummary(BaseModel):
    total_solved: int
    total_correct: int
    total_wrong: int
    accuracy_percent: float
    streak_days: int


class TopicProgressItem(BaseModel):
    topic: str
    solved_count: int
    correct_count: int
    accuracy_percent: float


class DailyProgressItem(BaseModel):
    date: str
    solved: int
    correct: int
