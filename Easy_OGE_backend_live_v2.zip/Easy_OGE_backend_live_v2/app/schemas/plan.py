from datetime import date, time
from pydantic import BaseModel, Field


class PlanCreateRequest(BaseModel):
    exam_date: date
    target_score: int = Field(ge=0, le=100)
    daily_minutes: int = Field(ge=15, le=180)
    notification_time: time | None = None


class PlanResponse(BaseModel):
    id: int
    exam_date: date
    target_score: int
    daily_minutes: int
    tasks_per_day: int
    current_day: int
    is_active: bool

    model_config = {'from_attributes': True}
