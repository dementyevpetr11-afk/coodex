from pydantic import BaseModel


class TaskResponse(BaseModel):
    id: int
    task_number: int
    topic: str
    question_text: str
    algorithm_text: str
    is_open_answer: bool

    model_config = {'from_attributes': True}


class TaskCreate(BaseModel):
    task_number: int
    topic: str
    question_text: str
    algorithm_text: str
    correct_answer: str
    is_open_answer: bool = False
    difficulty: str | None = None


class AnswerCheckRequest(BaseModel):
    answer: str


class AnswerCheckResponse(BaseModel):
    is_correct: bool
    expected: str | None = None
    is_open_answer: bool
    message: str
