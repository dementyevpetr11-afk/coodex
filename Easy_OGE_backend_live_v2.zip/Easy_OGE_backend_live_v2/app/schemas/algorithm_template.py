
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class WorkedExampleModel(BaseModel):
    example: list[str]
    thinking: list[str]
    notice: list[str]
    assembly: list[str]
    why_counted: list[str]


class AntiMistakeModel(BaseModel):
    lead: str
    items: list[str]


class AuthoringAlgorithmTemplateResponse(BaseModel):
    task_number: int
    task_code: str
    source_sheet: str | None = None
    what_is_it: str
    recognize_fast: str
    first_move: str
    answer_route: list[str]
    anti_mistake: AntiMistakeModel
    answer_template: list[str]
    memory_anchor: str
    worked_example: WorkedExampleModel
    priority: str | None = None
    next_action: str | None = None


class MachineMetaResponse(BaseModel):
    task_number: int
    task_code: str
    task_family: str
    format_type: str
    visual_type: str
    response_mode: str
    answer_source: str
    response_pattern: str
    required_elements_count: int | None = None
    required_elements: list[str]
    needs_examples: bool
    needs_argumentation: bool
    needs_definition: bool
    needs_comparison: bool
    needs_text_reference: bool
    anti_pattern_code: str
    ui_mode: str
    main_type: str
    priority_tier: str
    backend_endpoint: str
    view_keys: dict[str, Any]


class MobileShortCardResponse(BaseModel):
    task_number: int
    task_code: str
    main_type: str
    headline: str
    ui_short_hint: str
    route_3: list[str]
    anti_pattern_short: str
    memory_anchor: str
    ui_mode: str
    route_3_actions: list[str] | None = None
    route_3_cues: list[str] | None = None


class AlgorithmBundleResponse(BaseModel):
    task_number: int
    task_code: str
    authoring: AuthoringAlgorithmTemplateResponse
    machine_meta: MachineMetaResponse | None = None
    mobile_short_card: MobileShortCardResponse | None = None


class TestMapItemResponse(BaseModel):
    task_number: int
    main_type: str
    first_capture: str
    short_support: str


class PriorityMapItemResponse(BaseModel):
    task_number: int
    status: str
    next_action: str
