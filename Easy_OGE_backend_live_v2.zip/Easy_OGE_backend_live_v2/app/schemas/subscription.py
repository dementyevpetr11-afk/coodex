from datetime import datetime
from pydantic import BaseModel

from app.models.subscription import PlanType, SubscriptionStatus


class SubscriptionResponse(BaseModel):
    plan_type: PlanType
    status: SubscriptionStatus
    started_at: datetime
    expires_at: datetime | None = None
    activated_by_admin: str | None = None

    model_config = {'from_attributes': True}


class ManualActivationRequest(BaseModel):
    user_id: int
    plan_type: PlanType
