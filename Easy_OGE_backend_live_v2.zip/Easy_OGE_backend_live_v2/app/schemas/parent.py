from pydantic import BaseModel


class LinkStudentRequest(BaseModel):
    access_code: str


class ParentDashboardResponse(BaseModel):
    student_name: str
    total_solved: int
    total_correct: int
    accuracy_percent: float
    streak_days: int
    last_activity_at: str | None = None
    topics: list[dict]
