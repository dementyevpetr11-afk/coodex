
from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel

from app.models.open_answer import OpenAnswerStatus


class OpenAnswerSubmitRequest(BaseModel):
    task_id: int
    answer_text: str


class OpenAnswerReviewRequest(BaseModel):
    manager_score: int
    manager_comment: str


class OpenAnswerSubmissionResponse(BaseModel):
    id: int
    student_id: int
    task_id: int
    answer_text: str
    status: OpenAnswerStatus
    ai_score: int | None = None
    ai_comment: str | None = None
    ai_payload_json: str | None = None
    manager_score: int | None = None
    manager_comment: str | None = None
    created_at: datetime
    reviewed_at: datetime | None = None

    model_config = {'from_attributes': True}
