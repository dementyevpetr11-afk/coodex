from datetime import date, timedelta
from collections import defaultdict


def normalize_answer(answer: str) -> str:
    return ' '.join(answer.strip().lower().split())


def calculate_streak(activity_dates: list[date]) -> int:
    if not activity_dates:
        return 0
    unique_dates = sorted(set(activity_dates), reverse=True)
    streak = 0
    expected = unique_dates[0]
    for current in unique_dates:
        if current == expected:
            streak += 1
            expected = expected - timedelta(days=1)
        else:
            break
    return streak


def group_daily_counts(items: list[tuple[date, int, int]]) -> list[dict]:
    grouped = defaultdict(lambda: {'solved': 0, 'correct': 0})
    for day, solved, correct in items:
        grouped[day]['solved'] += solved
        grouped[day]['correct'] += correct
    result = []
    for day in sorted(grouped.keys()):
        result.append({'date': day.isoformat(), **grouped[day]})
    return result
